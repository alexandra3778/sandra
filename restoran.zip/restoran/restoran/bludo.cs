﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace restoran
{
    public partial class bludo : Form
    {
        private SqlConnection connection;
        private SqlCommand command;
        private SqlDataReader reader;
        string connectionString = @"Data Source=LOCALHOST;Initial Catalog=restoran;Integrated Security=True";

        public bludo()
        {
            InitializeComponent();
            LoadBludoNames();
        }

        private void LoadBludoNames()
        {
            connection = new SqlConnection(connectionString);
            string query = "SELECT DISTINCT Название FROM Блюда"; 
            command = new SqlCommand(query, connection);

            connection.Open();
            reader = command.ExecuteReader();

            while (reader.Read())
            {
                comboBox1.Items.Add(reader["Название"].ToString()); 
            }

            reader.Close();
            connection.Close();
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            main form1 = new main();
            form1.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            string selected = comboBox1.SelectedItem.ToString();
            string query = "SELECT Название, Описание, Вид_блюда, Калорийность, Вес, Стоимость, Фотография FROM Блюда WHERE Название = @Блюда";
            command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Блюда", selected);

            connection.Open();
            reader = command.ExecuteReader();

            if (reader.Read())
            {
                txtName.Text = reader["Название"].ToString();
                txtvid.Text = reader["Вид_блюда"].ToString();
                txtcolor.Text = reader["Калорийность"].ToString();
                txtves.Text = reader["Вес"].ToString();
                txtcost.Text = reader["Стоимость"].ToString();
                txtdescription.Text = reader["Описание"].ToString();
                string imagePath = reader["Фотография"].ToString();
                pictureBox1.Image = Image.FromFile(imagePath);
            }

            reader.Close();
            connection.Close();
        }
    }
}


