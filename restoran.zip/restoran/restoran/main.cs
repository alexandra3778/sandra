﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace restoran
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void войтиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            authorization newForm2 = new authorization();
            newForm2.Show();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            bludo newForm3 = new bludo();
            newForm3.Show();
        }
    }
}
