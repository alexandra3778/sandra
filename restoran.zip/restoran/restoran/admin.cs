﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;

namespace restoran
{
    public partial class admin : Form
    {
        public admin()
        {
            InitializeComponent();
        }
     
        string connectionString = "Data Source=LOCALHOST;Initial Catalog=restoran;Integrated Security=True";
        private void admin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "restoranDataSet4.Блюда". При необходимости она может быть перемещена или удалена.
            this.блюдаTableAdapter1.Fill(this.restoranDataSet4.Блюда);
            
            // TODO: данная строка кода позволяет загрузить данные в таблицу "restoranDataSet2.Блюда". При необходимости она может быть перемещена или удалена.
            this.блюдаTableAdapter.Fill(this.restoranDataSet2.Блюда);
          
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string description = txtdescription.Text;
            string color = txtcolor.Text;
            string ves = txtves.Text;
            string cost = txtcost.Text;
            string imagePath = txtImage.Text;
            string type = comboBox1.Text;

         
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                 
                    connection.Open();

                    string query = "INSERT INTO Блюда (Название, Описание, Вид_блюда, Калорийность, Вес, Стоимость, Фотография) " +
                                   "VALUES (@name, @description, @type, @color, @ves, @cost, @imagePath)";

               
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                      
                        command.Parameters.AddWithValue("@name", name);
                        command.Parameters.AddWithValue("@description", description);
                        command.Parameters.AddWithValue("@type", type);
                        command.Parameters.AddWithValue("@color", color);
                        command.Parameters.AddWithValue("@ves", ves);
                        command.Parameters.AddWithValue("@cost", cost);
                        command.Parameters.AddWithValue("@imagePath", imagePath);

                        int rowsAffected = command.ExecuteNonQuery();

           
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Данные успешно сохранены");
                        }
                        else
                        {
                            MessageBox.Show("Произошла ошибка при сохранении данных");
                        }
                    }
                }
            
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Изображения (*.jpg, *.jpeg, *.png)|*.jpg; *.jpeg; *.png";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                   
                    string imagePath = openFileDialog.FileName;

                   
                    string destinationFolder = "C:\\Users\\Asus\\Desktop\\restoran\\restoran\\image";

                 
           
                    string fileName = Path.GetFileName(imagePath);
                    string destinationPath = Path.Combine(destinationFolder, fileName);

       
                    File.Copy(imagePath, destinationPath, true);

                    txtImage.Text = destinationPath;

                    MessageBox.Show("Изображение успешно сохранено.");
                }
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            блюдаBindingSource1.RemoveCurrent();
            this.блюдаTableAdapter1.Update(restoranDataSet4); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            блюдаBindingSource1.EndEdit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.блюдаBindingSource1.EndEdit();
                this.блюдаTableAdapter1.Update(restoranDataSet4);
                MessageBox.Show("Данные успешно сохранены");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения" + ex.Message);
            }
        }

        private void блюдаBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            main form1 = new main();
            form1.Show();
            this.Hide();
        }
    }

       
    
    }

