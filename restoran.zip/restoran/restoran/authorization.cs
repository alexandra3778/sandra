﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace restoran
{
    public partial class authorization : Form
    {
        private string userLogin;

        public authorization()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=LOCALHOST;Initial Catalog=restoran;Integrated Security=True";

            using (SqlConnection sqlcon = new SqlConnection(connectionString))
            {
                sqlcon.Open();
                string query = "SELECT COUNT(*) FROM Администраторы WHERE Логин = @Логин AND Пароль = @Пароль";
                SqlCommand command = new SqlCommand(query, sqlcon);
                command.Parameters.AddWithValue("@Логин", txtPassword.Text.Trim());
                command.Parameters.AddWithValue("@Пароль", txtPassword.Text.Trim());

                int adminCount = (int)command.ExecuteScalar();

                if (adminCount > 0)
                {
               
                    userLogin = txtPassword.Text;

                    admin form2 = new admin();
                    form2.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Проверьте свой логин и пароль");
                }
            }
        }
    }
}